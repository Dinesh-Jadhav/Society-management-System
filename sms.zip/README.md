# society-management
Society Managment on top of of the MEAN Stack 
