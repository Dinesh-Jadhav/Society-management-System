exports.addParking = function(pool) {
    return function(req, res) {
        res.setHeader('Content-Type', 'application/json');
        var block_id = req.body.block_id;
        var parking_name = req.body.name;
        var area = "";
        var result = {};
        if (block_id == '' || parking_name == '') {
            result.error = 'Parameter Missing';
            res.send(JSON.stringify(result));
            return;
        }
        var queryString = 'insert into parking_master(block_id, name, area) values("' + block_id + '", "' + parking_name + '", "' + area + '")';
        pool.query(queryString, function(err, rows, fields) {
            if (err) {
                result.error = err;
                console.log(err);
            } else {
                result.data = rows
                result.success = "parking added successfully";
                res.send(JSON.stringify(result));
            }
        });
    }
}

exports.getParkingList = function(pool) {
    return function(req, res) {

        var block_id = req.query.block_id;
        res.setHeader('Content-Type', 'application/json');
        var result = {};
        var query = 'select pm.*, fpm.parking_id, fpm.flat_id, fm.flat_number, concat(r.first_name, " ", r.last_name) as resident_name from parking_master pm left join flat_parking_association fpm on find_in_set(pm.id, fpm.parking_id) left join residents r on r.flat_id = fpm.flat_id left JOIN flat_master fm on fm.id=fpm.flat_id where pm.block_id="' + block_id + '"';
        query += " order by id desc";
        pool.query(query, function(err, rows, fields) {
            if (err) {
                console.log(err);
            } else {
                result.data = rows;
                res.send(JSON.stringify(result));
                return;
            }
        });
    }
};

exports.deleteAssingParking = function(pool) {
    return function(req, res) {
        res.setHeader('Content-Type', 'application/json');
        var id = req.body.id;
        var data = {}
        pool.query("DELETE FROM parking_master WHERE id=?", [id], function(err, rows, fields) {
            if (err) {
                data.error = err;
            } else {
                data.success = "slot deleted Successfully";
                res.send(JSON.stringify(data));
            }
        });
    };
};

exports.assingParking = function(pool) {
    return function(req, res) {
        var result = {};
        var flat_id = req.body.flat_id;
        var parking_id = req.body.parking_id;
        res.setHeader('content-Type', 'application/json');
        Q = 'select * from flat_parking_association where flat_id = "' + flat_id + '"';
        pool.query(Q, function(err, rows) {
            if (err) {
                result.error = err;
                console.log(err);
            } else {
                if (rows.length > 0) {
                    result.success = "this slot is already assigned";
                    res.send(JSON.stringify(result));
                    return;
                }
                var Q1 = 'insert into flat_parking_association (flat_id,parking_id,status) values ("' + flat_id + '","' + parking_id + '","1")';
                pool.query(Q1, function(err, rows) {
                    if (err) {
                        result.error = err;
                        console.log(err);
                    } else {
                        Q2 = 'update parking_master SET status = "1" where id="' + parking_id + '"';
                        pool.query(Q2, function(err, rows) {
                            if (err) {
                                result.error = err;
                                console.log(err);
                            } else {
                                result.success = "parking master updated";
                                result.success = "assign parking slot sucessfully";
                                res.send(JSON.stringify(result));
                            }
                        });
                    }
                });
            }
        });
    }
}

exports.listOfAssignParking = function(pool) {
    return function(req, res) {
        res.setHeader('content-Type', 'application/json')
        var result = {};
        var block_id = req.body.block_id;
        var Q = 'SELECT DISTINCT concat(r.first_name," " ,r.last_name) as resident_name,fm.flat_number as flat_number,fpa.parking_id as assign_parking_slots from residents r INNER JOIN flat_master fm ON r.flat_id = fm.id INNER JOIN flat_parking_association fpa On fm.id = fpa.flat_id INNER JOIN parking_master pm ON fm.block_id = pm.block_id where pm.block_id = "' + block_id + '"';

        /*SELECT concat(r.first_name," " ,r.last_name) as resident_name,fm.flat_number as flat_number,fpa.parking_id AS assign_parking_slots from flat_parking_association fpa INNER JOIN parking_master pm ON fpa.parking_id = find_in_set(pm.id,fpa.parking_id) INNER JOIN flat_master fm ON fm.block_id = pm.block_id INNER JOIN residents r ON r.flat_id = fm.id where pm.block_id = "1" group by pm.block_id*/
        pool.query(Q, function(err, rows) {
            if (err) {
                console.log(err);
            } else {
                result.data = rows;
                result.success = "parking list displayed successfully";
                res.send(JSON.stringify(result));
            }
        })
    }
}
