socialApp.controller('games', ['$scope', function($scope) {
    $scope.game = ['sdf', 'alksd'];
}]);
