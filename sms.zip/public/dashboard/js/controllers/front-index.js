
socialApp.controller('index',['$scope', '$http', '$location', '$compile','Upload', '$timeout', function ($scope, $http,$location, $compile, Upload, $timeout) {
		

}]);